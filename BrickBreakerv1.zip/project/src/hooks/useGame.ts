import { useCallback } from 'react';
import { Ball, Brick, PowerUp, Particle } from '../types';
import { INITIAL_GAME_STATE } from '../constants';
import { checkCollision, createParticles } from '../utils/physics';
import { generateLevel } from '../utils/levelGenerator';
import { useGameContext } from '../context/GameContext';

export const useGame = () => {
  const { setGameState } = useGameContext();

  const updateGameState = useCallback((deltaTime: number) => {
    setGameState(prevState => {
      if (prevState.isPaused || !prevState.isPlaying) return prevState;

      // Increase ball speed with level and time
      const levelSpeedMultiplier = 1 + (prevState.level * 0.08);
      
      // Update ball positions with time-based speed increase
      const updatedBalls = prevState.balls.map(ball => {
        const newBall = { ...ball };
        const timeSpeedMultiplier = 1 + (ball.timeAlive * 0.01); // Speed increases with time
        newBall.timeAlive += deltaTime;
        
        const totalSpeedMultiplier = levelSpeedMultiplier * timeSpeedMultiplier;
        newBall.x += ball.dx * ball.speed * totalSpeedMultiplier * deltaTime;
        newBall.y += ball.dy * ball.speed * totalSpeedMultiplier * deltaTime;

        // Wall collisions
        if (newBall.x - ball.radius <= 0 || newBall.x + ball.radius >= prevState.canvasWidth) {
          newBall.dx *= -1;
        }
        if (newBall.y - ball.radius <= 0) {
          newBall.dy *= -1;
        }

        // Ball lost
        if (newBall.y + ball.radius > prevState.canvasHeight) {
          return {
            ...INITIAL_GAME_STATE.balls[0],
            x: prevState.paddle.x + prevState.paddle.width / 2,
            timeAlive: 0
          };
        }

        // Paddle collision
        if (checkCollision(newBall, prevState.paddle)) {
          const hitPosition = (newBall.x - prevState.paddle.x) / prevState.paddle.width;
          newBall.dx = Math.sin(hitPosition * Math.PI) * 2;
          newBall.dy = -Math.abs(newBall.dy);
          // Add slight speed increase on paddle hit
          newBall.speed *= 1.02;
        }

        return newBall;
      });

      // Update power-ups
      const updatedPowerUps = prevState.powerUps
        .map(powerUp => ({
          ...powerUp,
          y: powerUp.y + powerUp.speed * deltaTime
        }))
        .filter(powerUp => powerUp.y < prevState.canvasHeight);

      // Update particles
      const updatedParticles = prevState.particles
        .map(particle => ({
          ...particle,
          x: particle.x + particle.dx * deltaTime,
          y: particle.y + particle.dy * deltaTime,
          life: particle.life - deltaTime
        }))
        .filter(particle => particle.life > 0);

      // Check for brick collisions and update score
      let updatedBricks = [...prevState.bricks];
      let updatedScore = prevState.score;
      let newParticles: Particle[] = [];

      updatedBalls.forEach(ball => {
        updatedBricks = updatedBricks.map(brick => {
          if (brick.health <= 0) return brick;
          
          if (checkCollision(ball, brick)) {
            ball.dy *= -1;
            const newBrick = { ...brick, health: brick.health - 1 };
            if (newBrick.health <= 0) {
              updatedScore += brick.points;
              newParticles.push(...createParticles(brick.x + brick.width / 2, brick.y + brick.height / 2));
            }
            return newBrick;
          }
          return brick;
        });
      });

      // Check for level completion
      const remainingBricks = updatedBricks.filter(brick => 
        brick.health > 0 && brick.type !== 'unbreakable'
      ).length;

      if (remainingBricks === 0) {
        const nextLevel = prevState.level + 1;
        return {
          ...prevState,
          level: nextLevel,
          bricks: generateLevel(nextLevel),
          balls: [{
            ...INITIAL_GAME_STATE.balls[0],
            speed: INITIAL_GAME_STATE.balls[0].speed * (1 + (nextLevel * 0.08)),
            timeAlive: 0
          }],
          powerUps: [],
          particles: [],
          isPlaying: false,
          paddle: {
            ...prevState.paddle,
            width: Math.max(100, INITIAL_GAME_STATE.paddle.width - (nextLevel * 3))
          }
        };
      }

      // Check for game over
      const allBallsLost = updatedBalls.every(ball => ball.y > prevState.canvasHeight);
      if (allBallsLost) {
        const newLives = prevState.lives - 1;
        if (newLives <= 0) {
          return {
            ...INITIAL_GAME_STATE,
            bricks: generateLevel(1)
          };
        }
        return {
          ...prevState,
          lives: newLives,
          isPlaying: false,
          balls: [{
            ...INITIAL_GAME_STATE.balls[0],
            x: prevState.paddle.x + prevState.paddle.width / 2,
            timeAlive: 0
          }]
        };
      }

      return {
        ...prevState,
        balls: updatedBalls,
        bricks: updatedBricks,
        powerUps: updatedPowerUps,
        particles: [...updatedParticles, ...newParticles],
        score: updatedScore
      };
    });
  }, [setGameState]);

  return { updateGameState };
};