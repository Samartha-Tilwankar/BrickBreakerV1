import { useState, useCallback } from 'react';
import { useGameContext } from '../context/GameContext';
import { INITIAL_GAME_STATE } from '../constants';

export const useGameState = () => {
  const { gameState, setGameState, highScore } = useGameContext();
  const [showMenu, setShowMenu] = useState(false);

  const togglePause = useCallback(() => {
    setGameState(prev => ({ ...prev, isPaused: !prev.isPaused }));
  }, [setGameState]);

  const resetGame = useCallback(() => {
    setGameState(INITIAL_GAME_STATE);
    setShowMenu(false);
  }, [setGameState]);

  return {
    isPlaying: gameState.isPlaying,
    isPaused: gameState.isPaused,
    score: gameState.score,
    lives: gameState.lives,
    level: gameState.level,
    highScore,
    showMenu,
    setShowMenu,
    togglePause,
    resetGame
  };
};