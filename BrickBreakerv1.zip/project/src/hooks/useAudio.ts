import { useState, useCallback } from 'react';

export const useAudio = () => {
  const [isMuted, setIsMuted] = useState(() => {
    const saved = localStorage.getItem('isMuted');
    return saved ? JSON.parse(saved) : false;
  });

  const toggleMute = useCallback(() => {
    setIsMuted(prev => {
      const newValue = !prev;
      localStorage.setItem('isMuted', JSON.stringify(newValue));
      return newValue;
    });
  }, []);

  return { isMuted, toggleMute };
};