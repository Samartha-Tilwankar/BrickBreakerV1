import { useCallback } from 'react';
import { useGameContext } from '../context/GameContext';

export const useControls = () => {
  const { gameState, setGameState } = useGameContext();

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (gameState.isPaused) return;

    const canvas = e.target as HTMLCanvasElement;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * gameState.canvasWidth;
    
    setGameState(prev => ({
      ...prev,
      paddle: {
        ...prev.paddle,
        x: Math.max(0, Math.min(x - prev.paddle.width / 2, prev.canvasWidth - prev.paddle.width))
      }
    }));
  }, [gameState.isPaused, gameState.canvasWidth, setGameState]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (gameState.isPaused) return;

    switch (e.code) {
      case 'ArrowLeft':
        setGameState(prev => ({
          ...prev,
          paddle: {
            ...prev.paddle,
            x: Math.max(0, prev.paddle.x - prev.paddle.speed / 60)
          }
        }));
        break;
      case 'ArrowRight':
        setGameState(prev => ({
          ...prev,
          paddle: {
            ...prev.paddle,
            x: Math.min(prev.canvasWidth - prev.paddle.width, prev.paddle.x + prev.paddle.speed / 60)
          }
        }));
        break;
      case 'Space':
        if (!gameState.isPlaying) {
          setGameState(prev => ({
            ...prev,
            isPlaying: true,
            balls: prev.balls.map(ball => ({
              ...ball,
              dy: -ball.speed,
              dx: (Math.random() - 0.5) * ball.speed
            }))
          }));
        }
        break;
    }
  }, [gameState.isPaused, gameState.isPlaying, setGameState]);

  const handleKeyUp = useCallback(() => {
    // Handle key up events if needed
  }, []);

  return {
    handleMouseMove,
    handleKeyDown,
    handleKeyUp
  };
};