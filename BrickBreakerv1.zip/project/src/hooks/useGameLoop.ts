import { useEffect, useRef } from 'react';
import { GameState, Brick, PowerUp } from '../types';

const getBrickColor = (brick: Brick, theme: GameState['theme']) => {
  switch (brick.type) {
    case 'reinforced': return theme.brickColors.reinforced;
    case 'unbreakable': return theme.brickColors.unbreakable;
    case 'powerup': return theme.brickColors.powerup;
    default: return theme.brickColors.normal[brick.colorIndex];
  }
};

const getPowerUpColor = (type: PowerUp['type']) => {
  switch (type) {
    case 'multiball': return '#ff0000';
    case 'wider': return '#00ff00';
    case 'laser': return '#ffff00';
    case 'slower': return '#0000ff';
    case 'faster': return '#ff00ff';
    default: return '#ffffff';
  }
};

export const useGameLoop = (
  canvasRef: React.RefObject<HTMLCanvasElement>,
  gameState: GameState,
  update: (deltaTime: number) => void
) => {
  const frameRef = useRef<number>();
  const lastTimeRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set canvas size
    canvas.width = gameState.canvasWidth;
    canvas.height = gameState.canvasHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = (timestamp: number) => {
      if (!lastTimeRef.current) {
        lastTimeRef.current = timestamp;
      }

      const deltaTime = (timestamp - lastTimeRef.current) / 1000;
      lastTimeRef.current = timestamp;

      // Clear canvas
      ctx.fillStyle = gameState.theme.backgroundColor;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Update game state
      update(deltaTime);

      // Render game objects
      renderGame(ctx, gameState);

      frameRef.current = requestAnimationFrame(render);
    };

    frameRef.current = requestAnimationFrame(render);

    return () => {
      if (frameRef.current) {
        cancelAnimationFrame(frameRef.current);
      }
    };
  }, [canvasRef, gameState, update]);
};

const renderGame = (ctx: CanvasRenderingContext2D, state: GameState) => {
  // Render paddle with gradient
  const paddleGradient = ctx.createLinearGradient(
    state.paddle.x,
    state.paddle.y,
    state.paddle.x,
    state.paddle.y + state.paddle.height
  );
  paddleGradient.addColorStop(0, state.theme.paddleColor);
  paddleGradient.addColorStop(1, '#000000');
  
  ctx.fillStyle = paddleGradient;
  ctx.fillRect(
    state.paddle.x,
    state.paddle.y,
    state.paddle.width,
    state.paddle.height
  );

  // Render balls with glow effect
  state.balls.forEach(ball => {
    ctx.beginPath();
    ctx.fillStyle = state.theme.ballColor;
    ctx.shadowBlur = 10;
    ctx.shadowColor = state.theme.ballColor;
    ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.closePath();
  });

  // Render bricks with 3D effect
  state.bricks.forEach(brick => {
    if (brick.health <= 0) return;
    
    const baseColor = getBrickColor(brick, state.theme);
    
    // Main brick body
    ctx.fillStyle = baseColor;
    ctx.fillRect(brick.x, brick.y, brick.width, brick.height);
    
    // Top highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.fillRect(brick.x, brick.y, brick.width, brick.height / 4);
    
    // Bottom shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.fillRect(brick.x, brick.y + brick.height * 0.75, brick.width, brick.height / 4);
    
    // Health indicator for reinforced bricks
    if (brick.type === 'reinforced' && brick.health > 1) {
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(
        brick.health.toString(),
        brick.x + brick.width / 2,
        brick.y + brick.height / 2 + 4
      );
    }
  });

  // Render particles with glow
  state.particles.forEach(particle => {
    ctx.beginPath();
    ctx.fillStyle = `rgba(${particle.color}, ${particle.life})`;
    ctx.shadowBlur = 5;
    ctx.shadowColor = `rgba(${particle.color}, ${particle.life})`;
    ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.closePath();
  });

  // Render power-ups with pulsing effect
  state.powerUps.forEach(powerUp => {
    ctx.fillStyle = getPowerUpColor(powerUp.type);
    ctx.beginPath();
    ctx.arc(powerUp.x, powerUp.y, powerUp.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.closePath();
  });

  // Render game info
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 24px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(`Score: ${state.score}`, 20, 40);
  ctx.fillText(`Level: ${state.level}`, 20, 70);
  ctx.fillText(`Lives: ${state.lives}`, 20, 100);

  // Show "Press SPACE to start" message if not playing
  if (!state.isPlaying) {
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(
      'Press SPACE to start',
      state.canvasWidth / 2,
      state.canvasHeight / 2
    );
  }
};