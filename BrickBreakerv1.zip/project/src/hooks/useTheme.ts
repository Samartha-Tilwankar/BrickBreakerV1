import { useState, useCallback } from 'react';
import { THEMES } from '../constants';

export const useTheme = () => {
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved || 'classic';
  });

  const updateTheme = useCallback((newTheme: string) => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
  }, []);

  return {
    theme,
    setTheme: updateTheme,
    themeColors: THEMES[theme]
  };
};