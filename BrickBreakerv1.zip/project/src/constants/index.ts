import { Theme, GameState } from '../types';

export const THEMES: Record<string, Theme> = {
  classic: {
    paddleColor: '#4f46e5',
    ballColor: '#ffffff',
    backgroundColor: '#000000',
    brickColors: {
      normal: ['#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4', '#6366f1'],
      reinforced: '#84cc16',
      unbreakable: '#64748b',
      powerup: '#d946ef'
    }
  },
  neon: {
    paddleColor: '#00ff00',
    ballColor: '#ff00ff',
    backgroundColor: '#000000',
    brickColors: {
      normal: ['#00ffff', '#ff00ff', '#ffff00', '#00ff00', '#ff0000', '#0000ff'],
      reinforced: '#ff00ff',
      unbreakable: '#ffffff',
      powerup: '#ffff00'
    }
  },
  retro: {
    paddleColor: '#c0c0c0',
    ballColor: '#ffffff',
    backgroundColor: '#000000',
    brickColors: {
      normal: ['#808080', '#a0a0a0', '#b0b0b0', '#c0c0c0', '#d0d0d0', '#e0e0e0'],
      reinforced: '#ffffff',
      unbreakable: '#404040',
      powerup: '#ffffff'
    }
  }
};

export const INITIAL_GAME_STATE: GameState = {
  isPlaying: false,
  isPaused: false,
  score: 0,
  lives: 5,
  level: 1,
  canvasWidth: 1600,
  canvasHeight: 1000,
  paddle: {
    x: 750,
    y: 950,
    width: 150,
    height: 20,
    speed: 1000
  },
  balls: [{
    x: 800,
    y: 930,
    dx: 0,
    dy: -1,
    radius: 12,
    speed: 500,
    timeAlive: 0
  }],
  bricks: [],
  powerUps: [],
  particles: [],
  theme: THEMES.classic
};