import React from 'react';
import { X } from 'lucide-react';
import { useGameState } from '../hooks/useGameState';
import { useTheme } from '../hooks/useTheme';

interface MenuProps {
  onClose: () => void;
}

export const Menu: React.FC<MenuProps> = ({ onClose }) => {
  const { highScore, resetGame } = useGameState();
  const { theme, setTheme } = useTheme();

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <div className="bg-gray-900 rounded-lg p-8 w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X size={24} />
        </button>

        <h2 className="text-2xl font-bold text-white mb-6">Game Menu</h2>

        <div className="space-y-6">
          <div>
            <h3 className="text-lg text-purple-300 mb-2">High Score</h3>
            <p className="text-white text-2xl font-bold">{highScore}</p>
          </div>

          <div>
            <h3 className="text-lg text-purple-300 mb-2">Theme</h3>
            <select
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
              className="w-full bg-gray-800 text-white rounded px-3 py-2"
            >
              <option value="classic">Classic</option>
              <option value="neon">Neon</option>
              <option value="retro">Retro</option>
            </select>
          </div>

          <div className="space-y-2">
            <button
              onClick={resetGame}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded transition-colors"
            >
              New Game
            </button>
            <button
              onClick={onClose}
              className="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition-colors"
            >
              Resume
            </button>
          </div>

          <div className="text-sm text-gray-400">
            <h3 className="font-bold mb-1">Controls:</h3>
            <ul className="space-y-1">
              <li>Mouse - Move paddle</li>
              <li>Left/Right Arrows - Move paddle</li>
              <li>Space - Launch ball / Shoot laser</li>
              <li>P - Pause game</li>
              <li>M - Toggle sound</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};