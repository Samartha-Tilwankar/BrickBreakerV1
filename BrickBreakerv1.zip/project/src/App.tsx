import React from 'react';
import { Settings, Volume2, VolumeX, Pause, Play } from 'lucide-react';
import { GameProvider } from './context/GameContext';
import { Game } from './components/Game';
import { Menu } from './components/Menu';
import { useAudio } from './hooks/useAudio';
import { useGameState } from './hooks/useGameState';

function AppContent() {
  const { 
    isPlaying, 
    isPaused, 
    togglePause, 
    score, 
    lives, 
    level,
    showMenu,
    setShowMenu 
  } = useGameState();
  
  const { isMuted, toggleMute } = useAudio();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 to-purple-900 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-black/30 backdrop-blur-sm rounded-lg shadow-2xl p-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex gap-4">
            <div className="text-white">
              <span className="text-purple-300">Score:</span> {score}
            </div>
            <div className="text-white">
              <span className="text-purple-300">Lives:</span> {lives}
            </div>
            <div className="text-white">
              <span className="text-purple-300">Level:</span> {level}
            </div>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={toggleMute}
              className="text-white hover:text-purple-300 transition-colors"
            >
              {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
            </button>
            <button 
              onClick={() => setShowMenu(true)}
              className="text-white hover:text-purple-300 transition-colors"
            >
              <Settings size={24} />
            </button>
            <button 
              onClick={togglePause}
              className="text-white hover:text-purple-300 transition-colors"
            >
              {isPaused ? <Play size={24} /> : <Pause size={24} />}
            </button>
          </div>
        </div>

        {/* Game Canvas */}
        <div className="relative w-full aspect-video bg-black/40 rounded-lg overflow-hidden">
          <Game />
          {isPaused && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
              <div className="text-4xl font-bold text-white">PAUSED</div>
            </div>
          )}
        </div>
      </div>

      {/* Menu Modal */}
      {showMenu && <Menu onClose={() => setShowMenu(false)} />}
    </div>
  );
}

function App() {
  return (
    <GameProvider>
      <AppContent />
    </GameProvider>
  );
}

export default App;