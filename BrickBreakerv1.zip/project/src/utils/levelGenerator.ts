import { Brick } from '../types';

export const generateLevel = (level: number): Brick[] => {
  const bricks: Brick[] = [];
  const rows = Math.min(6 + Math.floor(level / 2), 16);
  const cols = Math.min(12 + Math.floor(level / 3), 20);
  const brickWidth = 65;
  const brickHeight = 30;
  const padding = 6;
  const offsetTop = 50;
  const offsetLeft = (1600 - (cols * (brickWidth + padding))) / 2;

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const brickType = getBrickType(level, row);
      const health = getBrickHealth(brickType, level);
      
      bricks.push({
        x: col * (brickWidth + padding) + offsetLeft,
        y: row * (brickHeight + padding) + offsetTop,
        width: brickWidth,
        height: brickHeight,
        health,
        points: getBrickPoints(brickType, level),
        type: brickType,
        colorIndex: col % 6
      });
    }
  }

  return bricks;
};

const getBrickType = (level: number, row: number): Brick['type'] => {
  const random = Math.random();
  
  // More special bricks in higher levels
  if (level >= 3 && row === 0 && random < 0.2 + (level * 0.02)) {
    return 'unbreakable';
  }
  
  if (level >= 2 && random < 0.25 + (level * 0.03)) {
    return 'reinforced';
  }
  
  if (random < 0.15 + (level * 0.02)) {
    return 'powerup';
  }
  
  return 'normal';
};

const getBrickHealth = (type: Brick['type'], level: number): number => {
  switch (type) {
    case 'reinforced': return Math.min(5, 2 + Math.floor(level / 3)); // Max 5 hits
    case 'unbreakable': return Infinity;
    default: return 1;
  }
};

const getBrickPoints = (type: Brick['type'], level: number): number => {
  const levelMultiplier = 1 + (level * 0.15); // Increased point multiplier
  switch (type) {
    case 'reinforced': return Math.floor(50 * levelMultiplier);
    case 'powerup': return Math.floor(75 * levelMultiplier);
    case 'normal': return Math.floor(20 * levelMultiplier);
    default: return 0;
  }
};