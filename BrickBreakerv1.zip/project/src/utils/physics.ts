import { Ball, Brick, Paddle, Particle } from '../types';

export const checkCollision = (
  ball: Ball,
  object: Brick | Paddle
) => {
  const ballLeft = ball.x - ball.radius;
  const ballRight = ball.x + ball.radius;
  const ballTop = ball.y - ball.radius;
  const ballBottom = ball.y + ball.radius;

  const objectLeft = object.x;
  const objectRight = object.x + object.width;
  const objectTop = object.y;
  const objectBottom = object.y + object.height;

  return (
    ballLeft < objectRight &&
    ballRight > objectLeft &&
    ballTop < objectBottom &&
    ballBottom > objectTop
  );
};

export const createParticles = (x: number, y: number): Particle[] => {
  const particles: Particle[] = [];
  const numParticles = 8;

  for (let i = 0; i < numParticles; i++) {
    const angle = (i / numParticles) * Math.PI * 2;
    particles.push({
      x,
      y,
      dx: Math.cos(angle) * 200,
      dy: Math.sin(angle) * 200,
      size: 2,
      color: '255, 255, 255',
      life: 1
    });
  }

  return particles;
};