import React, { createContext, useContext, useState, useEffect } from 'react';
import { GameState } from '../types';
import { INITIAL_GAME_STATE } from '../constants';

interface GameContextType {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
  highScore: number;
  setHighScore: (score: number) => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [gameState, setGameState] = useState<GameState>(INITIAL_GAME_STATE);
  const [highScore, setHighScore] = useState<number>(() => {
    const saved = localStorage.getItem('highScore');
    return saved ? parseInt(saved, 10) : 0;
  });

  useEffect(() => {
    if (gameState.score > highScore) {
      setHighScore(gameState.score);
      localStorage.setItem('highScore', gameState.score.toString());
    }
  }, [gameState.score, highScore]);

  return (
    <GameContext.Provider value={{ gameState, setGameState, highScore, setHighScore }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGameContext = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGameContext must be used within a GameProvider');
  }
  return context;
};