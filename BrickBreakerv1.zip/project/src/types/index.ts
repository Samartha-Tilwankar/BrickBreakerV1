export interface Ball {
  x: number;
  y: number;
  dx: number;
  dy: number;
  radius: number;
  speed: number;
  timeAlive: number;
}

export interface Brick {
  x: number;
  y: number;
  width: number;
  height: number;
  health: number;
  points: number;
  type: 'normal' | 'reinforced' | 'unbreakable' | 'powerup';
  colorIndex: number;
}

export interface Paddle {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
}

export interface PowerUp {
  x: number;
  y: number;
  radius: number;
  speed: number;
  type: 'multiball' | 'wider' | 'laser' | 'slower' | 'faster';
}

export interface Particle {
  x: number;
  y: number;
  dx: number;
  dy: number;
  size: number;
  color: string;
  life: number;
}

export interface Theme {
  paddleColor: string;
  ballColor: string;
  backgroundColor: string;
  brickColors: {
    normal: string[];
    reinforced: string;
    unbreakable: string;
    powerup: string;
  };
}

export interface GameState {
  isPlaying: boolean;
  isPaused: boolean;
  score: number;
  lives: number;
  level: number;
  canvasWidth: number;
  canvasHeight: number;
  paddle: Paddle;
  balls: Ball[];
  bricks: Brick[];
  powerUps: PowerUp[];
  particles: Particle[];
  theme: Theme;
}